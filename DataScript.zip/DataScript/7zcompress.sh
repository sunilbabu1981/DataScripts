#!/bin/bash

if [[ $# < 2 ]] ; then
    echo "              "
    echo "Archives individual files in sourcedir subdirectories to zip files in archivedir"
    echo "      "
    echo "Usage:"
    echo "7zcompress.sh sourcedir archivedir"
    echo "   "
    exit 0
fi


for d in $1/* ; do
    if [ -d ${d} ]; then
        echo $d
        dirname=`basename $d`
        mkdir -p "$2/$dirname"
        echo $dirname
       for f in $d/* ; do
            filename=$(basename "$f")
            extension="${filename##*.}"
            filename="${filename%.*}"
            if [ -f "$f" ] && [[ $extension != *"tmp"* ]] && [[ $extension != *"mtime"* ]] && [ "X$(cat $f.mtime)" != "X$(stat -c %Y $f)" ] ; then
                echo $f
                7za u -up1q0r2x2y2z1w1 -stl -y -bd -tzip "$2/$dirname/$filename.zip" $f
                stat -c %Y $f > "$f.mtime"
            fi
        done
    fi
done

