#!/bin/bash

# Sync staging dirs with innovata input
#extractdir=/var/lib/HPCCSystems/mydropzone/input/innovata
#zipdir=/var/lib/HPCCSystems/mydropzone/input/innovata-staging
if [[ $# < 2 ]] ; then
    echo "              "
    echo "Extracts 7z files from archivedir into extractdir"
    echo "      "
    echo "Usage:"
    echo "7zextract.sh archivedir extractdir"
    echo "   "
    exit 0
fi

zipdir=$1
extractdir=$2


mkdir -p "$extractdir"

#process all 7z files
for f in $zipdir/*.7z
do
    echo "-----"
    echo "$f"

    filename="${f%.*}"

    if [ ! -f "$filename.md5" ]; then
        echo "MD5 not present."
        7za x $f -bd -y -o$extractdir
        md5sum $f > "$filename.md5"

    else

        storedsum=`cat "$filename.md5"`
        latestsum=`md5sum "$f"`

        if  ! md5sum -c "$filename.md5" ; then
            echo "MD5 mismatch for $f"

            #Safely remove the dir
            bfn=`basename $filename`

            if [ -d "$extractdir/$bfn" ]; then
                echo "Removing old dir $extractdir/$bfn"
                rm -rf "$extractdir/$bfn"
            fi

            7za x $f -bd -y -o$extractdir
            md5sum $f > "$filename.md5"
        else
            echo "MD5 matches, nothing to do."
        fi

    fi
done


#Cleanup orphaned 7z files
for f in $zipdir/*.md5
do
    filename="${f%.*}"
    if [ ! -f "$filename.7z" ]; then
        echo "Cleaning up md5 without corresponding 7z"
        rm "$filename.md5"
    fi
done
