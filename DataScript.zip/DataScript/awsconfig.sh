#!/bin/bash

export HTTPS_PROXY=https://webproxy.aeb.rbxd.ds:3128/
export HTTP_PROXY=http://webproxy.aeb.rbxd.ds:3128/
export AWS_CONFIG_FILE=/usr/local/bin/hammer/awsconfig
export INNOVATA_INPUT_BUCKET=fg-prod-hpcc-input/travelbase
export INNOVATA_INPUT_ARCHIVE_BUCKET=fg-prod-hpcc-input-archive/travelbase
export INNOVATA_OUTPUT_BUCKET=aeb-systest-hpcc-output/hammer

