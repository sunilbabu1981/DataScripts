#!/bin/bash

PATH=$PATH:/sbin:

for i in $(service hpcc-init status | awk '{print $1}')
do
    service hpcc-init -c $i status > /dev/null 2>&1

    if [[ $? -ne 0 ]]; then

        if [[ $i -eq "mythor" ]]; then
            echo "THOR is down"
            /opt/HPCCSystems/sbin/hpcc-run.sh -a hpcc-init stop
            sleep 2
            /opt/HPCCSystems/sbin/hpcc-run.sh -a hpcc-init start
        else
            echo "Restarting $i"
            service hpcc-init -c $i start > /dev/null 2>&1
        fi
        sleep 5
    else
        continue
    fi

    service hpcc-init -c $i status > /dev/null 2>&1

    if [[ $? -ne 0 ]]; then
        echo "Process $i down and failed to restart" | mailx -s "$i down on $(hostname)" RaviShankar.Dhamodharan@flightglobal.com sunil.babu@rbi.co.uk Srinivas.Sivasubramanian@flightglobal.com
    fi
done