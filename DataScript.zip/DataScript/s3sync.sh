#!/bin/bash

if ps -ef | grep -v grep | grep 'aws\|7za\|md5sum' ; then

    exit 0

else

    source /usr/local/bin/hammer/awsconfig.sh

    # Sync all the input file to the archive bucket
    aws s3 sync s3://$INNOVATA_INPUT_BUCKET s3://$INNOVATA_INPUT_ARCHIVE_BUCKET --profile hpccinputprod

    # Sync innovata input 7z files with staging dir
    aws s3 sync s3://$INNOVATA_INPUT_BUCKET /var/lib/HPCCSystems/mydropzone/input/innovata-staging --profile hpccinputprod --delete --exclude '*.md5' --exclude '*.mtime'

    #Extract 7z files for innovata-input
    /usr/local/bin/hammer/7zextract.sh /var/lib/HPCCSystems/mydropzone/input/innovata-staging /var/lib/HPCCSystems/mydropzone/input/innovata/warehouseloads

    #Copy regular files for innovata-input
    rsync -av --exclude='*.7z' --exclude='*.md5' --exclude='*.mtime' /var/lib/HPCCSystems/mydropzone/input/innovata-staging/ /var/lib/HPCCSystems/mydropzone/input/innovata/warehouseloads

    # Cleanup warehouse loads dir, remove old files
    find /var/lib/HPCCSystems/mydropzone/input/innovata/warehouseloads/* -prune -type d -mtime +45 -exec rm -rf {} \;

    # Cleanup output folder, remove old files and folders
    find /var/lib/HPCCSystems/mydropzone/output/innovata-staging/* -type d -mtime +30 -exec rm -rf {} \;
    find /var/lib/HPCCSystems/mydropzone/output/innovata/* -type d -mtime +30 -exec rm -rf {} \;

    #Archive output to 7z
    /usr/local/bin/hammer/transformoutput.sh /var/lib/HPCCSystems/mydropzone/output/innovata /var/lib/HPCCSystems/mydropzone/output/innovata-staging

    # Sync archived 7z with S3
    aws s3 sync /var/lib/HPCCSystems/mydropzone/output/innovata-staging s3://$INNOVATA_OUTPUT_BUCKET  --profile hpcc --delete --exclude '*.md5' --exclude '*.mtime' --exclude '*.tmp' --exclude '*.tmp*'



    #Set permissions on all files
    chmod -R 755 /var/lib/HPCCSystems/mydropzone/input
    chmod -R 755 /var/lib/HPCCSystems/mydropzone/output

fi
