#!/bin/bash

if [[ $# < 2 ]] ; then
    echo "              "
    echo "Archives individual files in sourcedir subdirectories to zip files in archivedir"
    echo "      "
    echo "Usage:"
    echo "transformoutput.sh sourcedir archivedir"
    echo "   "
    exit 0
fi

isDirectFile() {
    filenames=(Flightglobal_ Seabury_ ViajesAlameda_ WebCargo_ Webport_ WWInfoNetwork_ XiamenAir_ Yahoo_ 7L_Freight_ ForwardKeys_ GoHawk_ HitchHiker_ HolidayExtras_ InflightService_ IntlPost_ JRTechnologies_ Maukua_ OneTwoTrip_ Radius_ Cornerstone_ Dachser_ DataInsights_)
    for i in "${filenames[@]}"
    do
        if [[ ${1^^} == ${i^^}* ]] ;
        then
            return 0
        fi
    done
    return 1
}

isGlobalDirectFile() {
        filenames=(GlobalDirects\(full-All\)_ GlobalDirects\(full-AllwSeats\)_ GlobalDirects\(full-Cargo\)_ GlobalDirects\(full-Pax\)_ GlobalDirects\(full-PaxwSeats\)_ GlobalDirects\(sampleAllwSeats\)_ GlobalDirects\(sampleAll\)_)
    for i in "${filenames[@]}"
    do
        if [[ ${1^^} == ${i^^}* ]] ;
        then
            return 0
        fi
    done
    return 1
}

isFGInternalFeed() {
    filenames=(InFlightServiceInformationData_)
    for i in "${filenames[@]}"
    do
        if [[ ${1^^} == ${i^^}* ]] ;
        then
            return 0
        fi
    done
    return 1
}

isConnexFile() {
    filenames=(conducive_flights_ conducive_legs_ new-ng_ panacea_ princetonflights_ flights3_ stkload_ globalconnex_ TripAdvisor_)
    for i in "${filenames[@]}"
    do
        if [[ ${1^^} == ${i^^}* ]] ;
        then
            return 0
        fi
    done
    return 1
}

isStandardReferenceFile() {

    fileEndings=( _STD.DAT _STDH.DAT _sample.DAT )

    for i in "${fileEndings[@]}"
    do
        if [[ ${1^^} == *${i^^} ]] ;
        then
            return 0
        fi
    done
    return 1
}

isCustomReferenceFile() {

    custFileRegex="(CARRIERS|EQUIPMENT|MCT|STATIONS|TIMEZONES)_([^_]*)_.*"

    if [[ ${1^^} =~ $custFileRegex ]] ;
    then
            return 0
    else
        return 1
    fi
}


for d in $1/* ; do
    if [ -d ${d} ]; then
        echo "Processing directory $d"
        dirname=`basename $d`

        #Create the directories we'll be copying files to
        mkdir -p "$2/$dirname/"{CONNEX,STANDARD_REFERENCE,CUSTOM_REFERENCE,Data-QA,GlobalDirectFiles,FlightGlobal}

        for f in $d/* ; do
            #Extract the basename and extension for easier processing
            filename=$(basename "$f")
            extension="${filename##*.}"
            filename="${filename%.*}"

            #Checking for unprocessed or recently updated files to process
            if  [ -f "$f" ] && \
                [[ $extension != *"tmp"* ]] && \
                [[ $extension != *"mtime"* ]] && \
                [[ ! -f "$f.mtime" || "$(cat $f.mtime)" != "$(stat -c %Y $f)" ]]
                then
                echo "Processing $f"
                if isConnexFile $filename; then
                    echo "$filename is a CONNEX file"
                    7za u -up1q0r2x2y2z1w1 -stl -y -bd -tzip "$2/$dirname/CONNEX/$filename.zip" $f
                                elif isDirectFile $filename; then
                    echo "$filename is a DIRECT file"
                    7za u -up1q0r2x2y2z1w1 -stl -y -bd -tzip "$2/$dirname/Data-QA/$filename.zip" $f
                                elif isGlobalDirectFile $filename; then
                    echo "$filename is a GlobalDirectFiles file"
                    7za u -up1q0r2x2y2z1w1 -stl -y -bd -tzip "$2/$dirname/GlobalDirectFiles/$filename.zip" $f
                                elif isFGInternalFeed $filename; then
                    echo "$filename is a FG file"
                    7za u -up1q0r2x2y2z1w1 -stl -y -bd -tzip "$2/$dirname/FlightGlobal/$filename.zip" $f
                                elif isStandardReferenceFile $f; then
                    echo "$filename is a STANDARD_REFERENCE file"
                    cp $f "$2/$dirname/STANDARD_REFERENCE/"
                elif isCustomReferenceFile $filename; then
                    echo "$filename is a CUSTOM_REFERENCE file"
                    cp $f "$2/$dirname/CUSTOM_REFERENCE/"
                else
                    echo "Uncategorized file"
                    cp $f "$2/$dirname/"
                fi

                #Store the file's mod time for comparison next time this script runs
                stat -c %Y $f > "$f.mtime"
            fi

        done
    fi
done
