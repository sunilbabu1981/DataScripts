'''
Created on Dec 29, 2016

@author: RanjBa01
'''
import base64, cgi, ConfigParser, datetime, httplib, time, xml.dom.minidom, os.path, sys, string, socket, shutil, bz2, subprocess
from subprocess import Popen
from email_lib import email_func

class ECLClass(object):
    '''
    classdocs
    '''

    DVI_READY = '10'
    DVI_PROCESSING = '15'
    DVI_COMPLETE = '20'
    SPOT_PROCESSING = '25'
    SPOT_COMPLETE = '30'
    POST_PROCESSING = '35'
    POST_PROCESSING_COMPLETE = '40'

    SOAP_HEADER = '''\
    <?xml version="1.0" encoding="utf-8" ?>
    <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                   xmlns:xsd="http://www.w3.org/XMLSchema"
                   xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"
                   xmlns:SOAP-ENC="http://schemas.xmlsoap.org/soap/encoding/"
                   xmlns:wsse="http://schemas.xmlsoap.org/ws/2002/04/secext">
        <soap:Header>
            <wsse:Security>
                <wsse:UsernameToken>
                    <wsse:Username>%s</wsse:Username>
                    <wsse:Password>%s</wsse:Password>
                </wsse:UsernameToken>
                <wsse:RealmToken>
                    <wsse:Realm />
                </wsse:RealmToken>
            </wsse:Security>
        </soap:Header>
    <soap:Body>
    '''
    
    
    SOAP_FOOTER = '''\
    </soap:Body>
    </soap:Envelope>
    '''


    env='DEV';
    fname='./ecllib.properties';
    thor_settings=[];
    
    def __init__(self,envP='DEV',fnameP='./ecllib.properties'):
        self.env=envP;
        self.fname=fnameP;
        self.thor_settings=self.read_settings();
        return;
        
        
    def get_status_code(self,status):
        if (status == 'DVI_READY'):
            return self.DVI_READY
        elif (status == 'DVI_PROCESSING'):
            return self.DVI_PROCESSING
        elif (status == 'DVI_COMPLETE'):
            return self.DVI_COMPLETE
        elif (status == 'SPOT_PROCESSING'):
            return self.SPOT_PROCESSING
        elif (status == 'SPOT_COMPLETE'):
            return self.SPOT_COMPLETE
        elif (status == 'POST_PROCESSING'):
            return self.POST_PROCESSING
        elif (status == 'POST_PROCESSING_COMPLETE'):
            return self.POST_PROCESSING_COMPLETE
    
    def time_delta_to_message(self,diff):
        '''Turn a time delta into a human-readable message.'''
        (days,  secs) = (diff.days, diff.seconds)
        (hours, secs) = divmod(secs, 3600)
        (mins,  secs) = divmod(secs, 60)
        message = ""
        if days:
            message += '{0} day(s), '.format(days)
        if any([days, hours]):
            message += '{0} hour(s), '.format(hours)
        if any([days, hours, mins]):
            message += '{0} minute(s), '.format(mins)
        if any([days, hours, mins, secs]):
            message += '{0} second(s)'.format(secs)
        else:
            message = '0 seconds'
        return message;
    
    def get_node_text(self,doc, str_list):
        '''Find the text from a particular node in the SOAP response.'''
        leaf = doc.documentElement
        for item in str_list:
            try:
                leaf = leaf.getElementsByTagName(item)[0]
            except IndexError:
                return ''
        try:
            return str(leaf.firstChild.wholeText).strip()
        except AttributeError:
            raise ValueError(   
                '"%s" does not correspond to a text node.' % (', '.join(str_list)))
        return;
    
    def create_workunit(self,username, password, esp):
        '''Create the Work Unit.'''
        body = ('<WUCreate xmlns="http://webservices.seisint.com/WsWorkunits">\n' +
                '</WUCreate>\n')
        doc = self.make_soap_call(username, password, esp, body)
        wuid = self.get_node_text(doc, ['soap:Body', 'WUCreateResponse', 'Workunit', 'Wuid'])
        return wuid

    def attach_ecl_to_workunit(self,username, password, esp, wuid, jobname, querytext):
        '''Attach ECL to the Work Unit.'''
        body = ('<WUUpdate xmlns="http://webservices.seisint.com/WsWorkunits">\n' +
                '<Wuid>' + wuid + '</Wuid>\n' +
                '<Jobname>' + jobname + '</Jobname>\n' +
                '<QueryText>' + cgi.escape(querytext) + '</QueryText>\n' +
                '<AddDrilldownFields>0</AddDrilldownFields>\n' +
                '</WUUpdate>\n')
        self.make_soap_call(username, password, esp, body)



    def read_settings(self):
        '''Read the "ecllib.properties" file, as a dict of dicts. Be strict about
           the contents, so that there is no possibility for errors later on.'''
        parser = ConfigParser.ConfigParser()
        if not parser.read(self.fname):
            raise IOError('Could not read properties file "{0}".'.format(self.fname))
        sections = parser.sections()
        if not sections:
            raise IOError('Properties file "{0}" does not contain any sections.'.format(self.fname))
        result = {}
        for section in sections:
            result[section] = {}
            for name in ['esp', 'username', 'password', 'cluster', 'queue', 'ip']:
                value = parser.get(section, name)
                if not value:
                    raise IOError(
                        'In properties file "{0}", Section "{1}" doesn\'t have an entry for "{2}".'.format(
                            self.fname, section, name))
                result[section][name] = value
        return result; 

    def make_soap_call(self,username, password, esp, body):
        '''Make a SOAP call to the out to the HPCC.'''
        soap_msg = (self.SOAP_HEADER % (username, password)) + body + self.SOAP_FOOTER
        auth_str = base64.encodestring('%s:%s' % (username, password))[:-1]
        # Call the web service.
        service = httplib.HTTP(esp)
        service.putrequest('POST', '/WsWorkunits')
        service.putheader('Host', esp)
        service.putheader('User-Agent', 'eclplus-1.0')
        service.putheader('Content-type', 'text/xml; charset=UTF-8')
        service.putheader('Content-length', '%d' % len(soap_msg))
        service.putheader('SOAPAction', '""')
        service.putheader('Authorization', 'Basic %s' % auth_str)
        service.endheaders()
        service.send(soap_msg)
        # Get the response.
        (status_code, status_msg, headers) = service.getreply()
        headerLines = '\n'.join(headers)
        if status_code != 200:
            textLines = ['Response: %s %s' % (str(status_code) , status_msg),
                         'Headers: ']
            text = '\n'.join(textLines) + headerLines
            raise ValueError('SoapCall failed %s' % text)
        result = service.getfile().read()
        # Parse the response, and check for SOAP exceptions.
        doc = xml.dom.minidom.parseString(result)
        exception_msg = self.get_node_text(doc,
            ['soap:Body', 'WUCreateResponse', 'Exceptions', 'Exception', 'Message'])
        if exception_msg:
            raise ValueError(exception_msg)
        return doc
    
    def read_dvi_settings(self,dvi_fname):
        '''Read the DVI client-specific properties file'''
        propDict = dict()
        
        try:
            propFile = file(dvi_fname)
            for propLine in propFile:
                propDef= propLine.strip()
                if len(propDef) == 0:
                    continue
                if propDef[0] in ( '!', '#' ):
                    continue
                punctuation= [ propDef.find(c) for c in '=' ] + [ len(propDef) ]
                found= min( [ pos for pos in punctuation if pos != -1 ] )
                name= propDef[:found].rstrip()
                value= propDef[found:].lstrip("=").rstrip()
                propDict[name]= value
                
            propFile.close()
        except StandardError as e:
            raise ValueError('ecllib.py.read_dvi_settings():\n' + str(e))
        return propDict
    
    def call_ecl(self, projectID, jobname, querytext, hostname, fileName):
            '''Call some ECL code out on the HPPC.
               This returns a tuple of the work unit ID plus the status.'''
            # Use the environment to figure out our thor_settings.
            try:
                env_options = self.thor_settings[self.env]
            except KeyError:
                msg = ', '.join(sorted(self.thor_settings.get_keys()))
                raise ValueError('Plaform needs to be one of: {0}.'.format(msg))
            esp      = env_options['esp']
            username = env_options['username']
            password = env_options['password']
            cluster  = env_options['cluster']
            queue    = env_options['queue']
            ip       = env_options['ip']
        
            # Then, run the workunit.
            try:
                wuid = self.create_workunit(username, password, esp)
            except StandardError as e:
                raise ValueError('Error getting wuid: ' + str(e))
            try:
                self.attach_ecl_to_workunit(username, password, esp, wuid, jobname, querytext)
            except StandardError as e:
                raise ValueError('Error attaching ecl to workunit: ' + str(e))
        
            try:
                start_time = datetime.datetime.now()
                startTime = start_time.strftime('%Y%m%d %H:%M:%S')
                self.submit_workunit(username, password, esp, wuid, cluster, queue)
            except StandardError as e:
                raise ValueError('Error submitting workunit: ' + wuid + '\n' + str(e))
        
            subject = " ECL Started "
            #email_func(self.env, projectID, subject, "", "S", hostname, ip, fileName, wuid, startTime, "", "")
            status = self.wait_for_completion(username, password, esp, wuid)
            end_time = datetime.datetime.now()
            diff_time = end_time - start_time
            diff_msg  = self.time_delta_to_message(diff_time)
            endTime = end_time.strftime('%Y%m%d %H:%M:%S')
            #email_func(self.env, projectID, subject, "", "C", hostname, ip, fileName, wuid, startTime, endTime, diff_msg)
            #print 'back from ecl'
            return (wuid, status, diff_msg, startTime, endTime);
        
    def submit_workunit(self,username, password, esp, wuid, cluster, queue):
        '''Submit the Work Unit.'''
        body = ('<WUSubmit xmlns="http://webservices.seisint.com/WsWorkunits">\n' +
                '<Wuid>' + wuid + '</Wuid>\n' +
                '<Cluster>' + cluster + '</Cluster>\n' +
                '<Queue>' + queue + '</Queue>\n' +
                '<Snapshot></Snapshot>\n' +
                '</WUSubmit>\n')
        self.make_soap_call(username, password, esp, body);
    
    
    def wait_for_completion(self,username, password, esp, wuid):
        '''Wait for the Work Unit to complete.'''
        # Wait 10 seconds between each request, to play nice with the ESP.
        body = ('<WUWaitComplete xmlns="http://webservices.seisint.com/WsWorkunits">\n' +
                '<Wuid>' + wuid + '</Wuid>\n' +
                '<Wait>-1</Wait>\n' +
                '</WUWaitComplete>\n')
        state_id = 0
        while state_id == 0:
            time.sleep(10)
            doc = self.make_soap_call(username, password, esp, body)
            state_id = self.get_node_text(doc, ['soap:Body', 'WUWaitResponse', 'StateID'])
            if state_id:
                state_id = int(state_id)
            else:
                state_id = 0
        state_text = ['unknown',   'compiled',  'running', 'completed', 'failed',
                      'archived',  'aborting',  'aborted', 'blocked',   'submitted',
                      'scheduled', 'compiling', 'size']
        return state_text[state_id];


#eclObj = ECLClass('DEV','./ecllib.properties');
#print eclObj.call_ecl('Testing', 'Balaji Test', 'OUTPUT(\'Hello\');', '', '');
#print eclObj;
