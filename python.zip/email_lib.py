#!/usr/bin/env python
'''A library for email '''

import smtplib
from email.mime.text import MIMEText

DevEmailGroup = ['balaji.ranjan@lexisnexis.com']
QAEmailGroup = ['balaji.ranjan@lexisnexis.com']
prodEmailGroup = ['balaji.ranjan@lexisnexis.com']

SMTP_SERVER = 'appmail.risk.regn.net'
debug=False


def email_func(env, projectID, subject, text, emailType, hostname, ip, 
               fileName, wuid, startTime, endTime, diffMsg, eclCount='', dbCount=''):
    status = ""

    if env == "PROD":
        emailUserGroup = prodEmailGroup
    if env == "DEV":
        emailUserGroup = DevEmailGroup
    if env == "QA":
        emailUserGroup = QAEmailGroup

    TO_ADDRS = emailUserGroup

    if emailType == 'C':
        emailSubject = projectID + " Informational" + subject + " "
        status = 'ECL Completed' 
    elif emailType == 'S':
        emailSubject = projectID + " Informational" + subject + " " 
        status = 'ECL Started'
    elif emailType == 'L':
        emailSubject = projectID + " Informational" + subject + " " 
        status = 'Loaded to Database'
    elif emailType == 'P':
        emailSubject = projectID + " Informational" + subject + " " 
        status = 'Post Processing Started'
    else:
        if env == "PROD":
            TO_ADDRS = emailUserGroup + DevEmailGroup

        emailSubject = projectID + " Error" + subject + " "
        status = 'Error' 

    bodyLines = ["IP Address: %s" % ip,
                 "Status: %s" % status,
                 "FileName: %s" % fileName,
                 "WorkUnit: %s" % wuid,
                 "Started Time: %s" % startTime,
                 "Completed Time: %s" % endTime,
                 "Duration: %s" % diffMsg,
                 "ECL Record Count: %s" % eclCount,
                 "DB Record Count: %s" % dbCount,
                  "Error Message: %s" % text]
    body = '\n'.join(bodyLines)

    msg = MIMEText(body)
    msg['Subject'] = emailSubject
    msg['From'] = "python@%s" % hostname
    msg['To'] = ';'.join(TO_ADDRS)

    if debug:
        print "---------------------------------------------------------"
        print "From: %s" % msg['From']
        print "To: %s" % msg['To']
        print "Subject: %s" % msg['Subject']
        print "----------------------------------------"
        print body
        print "---------------------------------------------------------"
    else:
        s = smtplib.SMTP(SMTP_SERVER)
        s.sendmail("python@"+hostname, TO_ADDRS, msg.as_string())
        s.set_debuglevel(0) #change to non zero for debug info
        s.quit()

    return

