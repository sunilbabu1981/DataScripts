import pyinotify, os, sys
from ECLModule import ECLClass

class MyEventHandler(pyinotify.ProcessEvent):

    inputPath='';
    wipPath='';
    outputPath='';
    def __init__(self,inp,wip,out):
	self.inputPath=inp;
	self.wipPath=wip;
	self.outputPath=out;
   
    def process_IN_ACCESS(self, event):
        print "ACCESS event:", event.pathname

    def process_IN_ATTRIB(self, event):
        print "ATTRIB event:", event.pathname

    def process_IN_CLOSE_NOWRITE(self, event):
        print "CLOSE_NOWRITE event:", event.pathname

    def process_IN_CLOSE_WRITE(self, event):
	self.moveFiles();
	self.triggerProcess();

    #This is called anytime a new file is created
    def process_IN_CREATE(self, event):
        print "CREATE event:", event.pathname

    def process_IN_DELETE(self, event):
        print "DELETE event:", event.pathname

    def process_IN_MODIFY(self, event):
        print "MODIFY event:", event.pathname

    def process_IN_OPEN(self, event):
        print "OPEN event:", event.pathname
    
    def moveFiles(self):
	for i in os.listdir(self.inputPath):
		os.rename(self.inputPath+i,self.wipPath+i);
  
    def triggerProcess(self):
	eclObj = ECLClass('DEV','./ecllib.properties');
	print eclObj.call_ecl('Testing', 'Balaji Test', 'OUTPUT(\'Hello\');', '', '');

def usage():
  print "Usage : python filewatcher.py <input> <wip> <output>";

def main():
    if( len(sys.argv) < 4) :
	usage();
        return;
    else:
        inputPath=sys.argv[1];
        wipPath=sys.argv[2];
        outputPath=sys.argv[3];

	print "wipPath="+wipPath;
	# watch manager
	wm = pyinotify.WatchManager()
	wm.add_watch(inputPath, pyinotify.ALL_EVENTS, rec=True)

	# event handler
	eh = MyEventHandler(inputPath,wipPath,outputPath);

	# notifier
	notifier = pyinotify.Notifier(wm, eh)
	notifier.loop()
        return;
	
if __name__ == '__main__':
    main()
