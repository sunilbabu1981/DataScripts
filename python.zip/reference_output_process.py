#!/usr/bin/env python
import subprocess, string, os, glob, shutil, sys, socket, datetime, cx_Oracle
from subprocess import Popen,PIPE
from email_lib import email_func
from ecllib import read_settings, time_delta_to_message, env, get_status_code

##################################################################################################
#
# 1. pick up the oldest trigger file in the reference/output directory
# 2. parse the trigger file name to get:
#     plan
#     run ID
#     database table name
# 3. Trigger file name example: AMERGRP-8291761-DVIAMERGRP846-20140205-util_prov_drg_cd-trigger.txt
# 4. Read the contents of the trigger file for
#     eclCount - count of records output by ECL
#     totalFiles - total number of database uploads expected to be performed
# 5. Get the DB parms and credentials from REF_CUST_DB_PROPS
# 6. Perform the upload
# 7. Error handling
#
##################################################################################################

def main():
    startTime=''
    endTime=''
    eclCount=''
    dbCount=''
    diff_msg=''
    fileName=''
    triggerLocation = ''
    projectID=''
    ip=''
    hostname=''
    masterDB_host = ''
    masterDB_sid = ''
    masterDB_user = ''
    masterDB_password = ''
    reportDB_user = ''
    dir_out = ''
    dir_err = ''
    dir_com = ''
    dir_ldr = ''
    spot_ver = ''

    try:        
        settings = read_settings()
        ip = settings[env]['ip']
        hostname = socket.gethostname()
        dbPort = settings[env]['db_port']
        masterDB_host = settings[env]['reference_masterDB_host']
        masterDB_sid = settings[env]['reference_masterDB_sid']
        masterDB_user = settings[env]['reference_masterDB_user']
        masterDB_password = settings[env]['reference_masterDB_password']
        dir_out = settings[env]['reference_dir_out']
        dir_err = settings[env]['reference_dir_err']
        dir_com = settings[env]['reference_dir_com']
        dir_ldr = settings[env]['reference_dir_ldr']

        fileLocation = dir_out
        trigList = glob.glob(dir_out+'/*trigger.txt')

        if len(trigList) is 0:
            sys.exit(0)

    # get the oldest trigger file in the output directory
        oldestFile = min(trigList, key=os.path.getctime)
        fileName = oldestFile #setting this so if there is an error this file will be in the email
        parsedFilename = string.split(os.path.basename(oldestFile),"-")
        ldrScript = os.path.join(dir_ldr,parsedFilename[2]+".ctl")
        deleteFileMask = parsedFilename[2] + '.txt'
        endPos = oldestFile.find('-trigger.txt',0)
        baseFileName = oldestFile[0:endPos]
        fileName = baseFileName + '.txt'
        deleteTriggerMask = parsedFilename[2] + '-trigger.txt'
        logFile = os.path.join(dir_err,baseFileName+'.log')
        fileNamePrefix = parsedFilename[0] + '-' + parsedFilename[1] + '-' + parsedFilename[2]

        projectID = fileNamePrefix
        f = open(oldestFile)
        trigParams = f.readline().strip().split(',')
        f.close()
        triggerLocation = oldestFile
    # eclCount is the number of records output by ECL in the file being uploaded
        eclCount = trigParams[0]
        
    # delete any prior versions of this upload file from the complete folder
        print('deleteFileMask: %s' % deleteFileMask)
        print('deleteTriggerMask: %s' % deleteTriggerMask)
        deleteList = os.listdir(dir_com)
        for f in deleteList:
            if (deleteFileMask in f or deleteTriggerMask in f):
                print('\nDeleting prior version of upload file %s:\n%s\n' % (fileName,os.path.join(dir_com,f)))
                os.remove(os.path.join(dir_com,f))

    # move the trigger file after parsing it for upload parameters to the complete folder 
        src_file = oldestFile
        dst_file = os.path.join(dir_com, os.path.basename(oldestFile))
        shutil.move(src_file, dst_file)
        triggerLocation = dst_file

    # move the file being uploaded from output to complete folder
        src_file = fileName
        dst_file = os.path.join(dir_com, os.path.basename(fileName))
        if env == 'DEV' or env == 'PROD':
            print('\nfileLocation: ' + fileLocation)
            print('fileName: ' + os.path.basename(fileName))
            print('dir_com: ' + dir_com)
            print('src_file: ' + src_file)
            print('dst_file: ' + dst_file + '\n') 
        shutil.move(src_file, dst_file)
        fileToUpload = dst_file
        fileLocation = dir_com

        if env == 'DEV' or env == 'PROD':
            print('File moved')

        start_time = datetime.datetime.now()
        startTime = start_time.strftime('%Y%m%d %H:%M:%S')

        if env == 'DEV' or env == 'PROD':
            print('\nFound trigger file ' + oldestFile)
            print('ECL record count: ' + eclCount)
            print('Beginning upload,')

        dbCount = run_SQLLDR(masterDB_user,dbPort,masterDB_password,masterDB_host,masterDB_sid,ldrScript,fileToUpload,logFile)

        end_time = datetime.datetime.now()
        diff_time = end_time - start_time
        diff_msg  = time_delta_to_message(diff_time)
        endTime = end_time.strftime('%Y%m%d %H:%M:%S')

# if upload was complete, remove SQLLDR log file and compress output file in complete folder
        if dbCount == eclCount:
            os.remove(logFile)
            retcode = subprocess.call(['bzip2', '-f', fileToUpload])
            if retcode != 0:
                raise StandardError('reference_output_process.py:main(): bzip2 failed return code %d filename = %s' %(retcode, fileToUpload))
            subject = ' Python Reference DB Load Completed, file moved to complete folder'
            email_func(env, projectID, subject, '', "L", hostname, ip, fileName, '', startTime, endTime, diff_msg, eclCount, dbCount)
        else:
            raise ValueError("reference_output_process.py:main(): ECL counts do not match DB counts")

    except StandardError as e:
        if env == 'DEV' or env == 'PROD':
            print('\n\nError in reference_output_process.py.main(): ' + str(e))
    # move trigger file to error folder
        src_file = triggerLocation
        dst_file = os.path.join(dir_err, os.path.basename(triggerLocation))
        
        if env == 'DEV' or env == 'PROD':
            print('\nTrigger filename: ' + src_file)
            print('\nError handling: Moving trigger ' + src_file + '\nto ' + dst_file + '\n')
        
        if (os.path.isfile(src_file)):
            shutil.move(src_file, dst_file)
        else:
            print('\nTrigger file ' + src_file + ' not found, move cancelled\n')
            
    # move upload file to error folder
        src_file = os.path.join(fileLocation, os.path.basename(fileName))
        dst_file = os.path.join(dir_err, os.path.basename(fileName))
        
        if env == 'DEV' or env == 'PROD':
            print('Upload filename: ' + fileName)
            print('\nError handling: Moving file ' + src_file + '\nto ' + dst_file + '\n')
        
        if os.path.isfile(src_file):
            shutil.move(src_file, dst_file)
        else:
            print('\nReference upload file ' + src_file + ' not found, move cancelled\n')

        subject = ' Python reference DB Load Failed'
        text = str(e)
        email_func(env, projectID, subject, text, "E", hostname, ip, fileName, '', startTime, endTime, diff_msg, eclCount, dbCount)


def run_SQLLDR(user,dbPort,password,host,sid,ctl_file,fileToUpload,logFile):
    sqlldr_cmd = 'sqlldr userid=' + user + '/' + password + '@' + host + ':' + dbPort + '/' + sid + ' control=' + ctl_file + ' data=' + fileToUpload + ' direct=true' + ' log=' + logFile
    dbCount = ''
    try:
        print('SQLLDR command string:\n' + sqlldr_cmd + '\n')

        idx = 6
        #p = Popen(['sqlldr',
           #'userid=%s/%s@%s:%s/%s' % (user,password,host,dbPort,sid),
           #'control=%s' % ctl_file,
           #'data=%s' % fileToUpload,
           #'direct=true',
           #'log=%s' % logFile],stdout=PIPE, stderr=PIPE)
        p = Popen(string.split(sqlldr_cmd," "),stdout=PIPE, stderr=PIPE)
            
        stdout,stderr = p.communicate()
        if (p.returncode != 0):
            raise RuntimeError("reference_output_process.py:run_SQLLDR(): SQLLDR failed, status code %s\nstdout:\n%r\nstderr:\n%r" % (p.returncode, stdout, stderr))

        countLine = string.split(stdout,'\n')[idx]
        dbCount = countLine.split()[-1].rstrip('.')
        
        if env == 'DEV' or env == 'PROD':
            print('Records uploaded from file ' + fileToUpload + ': ' + dbCount)
            
    except StandardError as e:
        #print(str(e))
        raise ValueError("reference_output_process.py:run_SQLLDR(): Error uploading data to customer DB:\n" + str(e))
    return dbCount


main()
